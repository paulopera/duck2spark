O objetivo desse projeto é tornar viável ataques de HID utilizando um digispark em máquinas configuradas para operar com teclados abnt2.

O arquivo **scancode-ascii-table.h** deve ser colocado dentro do diretório **C:\Users\USUÁRIO\AppData\Local\Arduino15\packages\digistump\hardware\avr\1.6.7\libraries\DigisparkKeyboard**

Alguns caracteres ainda não funcionam, entretanto já é viável executar ataques de HID.


![alt tag](https://i.stack.imgur.com/z5CeU.jpg)
